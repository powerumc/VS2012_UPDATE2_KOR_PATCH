﻿namespace $safeprojectname$.Models
{
    public class FacebookPicture
    {
        public string Url { get; set; }
    }
}
