﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using Newtonsoft.Json.Serialization;

namespace $safeprojectname$
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            // IQueryable 또는 IQueryable<T> 반환 유형을 갖는 작업에 대한 쿼리 지원을 사용하도록 설정하려면 다음 코드 행의 주석 처리를 해제하십시오.
            // 예기치 않았거나 악의적인 쿼리를 처리하지 않으려면 QueryableAttribute의 유효성 검사 설정을 사용하여 수신 쿼리가 유효한지 확인하십시오.
            // 자세한 내용은 http://go.microsoft.com/fwlink/?LinkId=279712를 참조하십시오.
            //config.EnableQuerySupport();

            // 응용 프로그램에서 추적을 사용하지 않도록 설정하려면 다음 코드 행을 주석 처리하거나 제거하십시오.
            // 자세한 내용은 http://www.asp.net/web-api를 참조하십시오.
            config.EnableSystemDiagnosticsTracing();

            // JSON 데이터에 카멜 케이스를 사용합니다.
            config.Formatters.JsonFormatter.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
        }
    }
}
